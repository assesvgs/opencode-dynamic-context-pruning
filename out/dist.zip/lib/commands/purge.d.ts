import type { Logger } from "../logger";
import type { SessionState, WithParts } from "../state";
import type { PluginConfig } from "../config";
export interface PurgeCommandContext {
    client: any;
    state: SessionState;
    config: PluginConfig;
    logger: Logger;
    sessionId: string;
    messages: WithParts[];
}
export declare function handlePurgeTriggerCommand(ctx: PurgeCommandContext): Promise<string>;
export declare function applyPendingPurgeTrigger(state: SessionState, messages: WithParts[], logger: Logger): void;
//# sourceMappingURL=purge.d.ts.map